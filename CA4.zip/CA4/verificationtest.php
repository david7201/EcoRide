<?php

require_once '../src/DBconnect.php';
require_once 'verification.php'; 

class VerificationTest
{
    protected $verificationProcessor;
    public $connection; // Assuming DBConnect class exists

    public function testVerifySuccess()
    {
        // Create an instance of required classes
        $verification = new Verification($this->connection); // Pass $connection as argument

        // Set verification details
        $verification->setFirstName('John');
        echo "First Name: " . $verification->getFirstName() . "<br>";

        $verification->setLastName('Doe');
        echo "Last Name: " . $verification->getLastName() . "<br>";

        $verification->setPhoneNumber('123456789');
        echo "Phone Number: " . $verification->getPhoneNumber() . "<br>";

        $verification->setPassportNumber('ABC123');
        echo "Passport Number: " . $verification->getPassportNumber() . "<br>";
    }
}

$verificationTest = new VerificationTest();

$verificationTest->testVerifySuccess();
?>
