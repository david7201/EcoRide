<?php
require_once '../src/DBconnect.php';
require_once 'car.php'; 
require_once 'verification.php'; 
require_once 'reservation.php'; 
require_once 'Payment.php';

class PaymentTest
{
    protected $paymentProcessor;
    public $connection; // Assuming DBConnect class exists

    public function testInsertPaymentSuccess()
    {
        // Create instances of required classes
        $car = new Car(); // Assuming Car class exists
        $verification = new Verification($this->connection); // Pass $connection as argument
        $reservation = new Reservation(); // Assuming Reservation class exists

        // Create an instance of Payment class with required parameters
        $this->paymentProcessor = new Payment($this->connection, $car, $verification, $reservation);

        // Set payment details
        $this->paymentProcessor->setAmount(100);
        echo "Amount: " . $this->paymentProcessor->getAmount() . "<br>";

        $this->paymentProcessor->setPaymentDate('2024-04-28');
        echo "Payment Date: " . $this->paymentProcessor->getPaymentDate() . "<br>";

        $this->paymentProcessor->setPaymentMethod('Credit Card');
        echo "Payment Method: " . $this->paymentProcessor->getPaymentMethod() . "<br>";

        $this->paymentProcessor->setCardNumber('1234567890123456');
        echo "Card Number: " . $this->paymentProcessor->getCardNumber() . "<br>";

        $this->paymentProcessor->setNameOnCard('connor ball');
        echo "Name on Card: " . $this->paymentProcessor->getNameOnCard() . "<br>";

        $this->paymentProcessor->setCVV('123');
        echo "CVV: " . $this->paymentProcessor->getCVV() . "<br>";

        $this->paymentProcessor->setExpirationDate('2024-12-31');
        echo "Expiration Date: " . $this->paymentProcessor->getExpirationDate() . "<br>";

        $this->paymentProcessor->setStatus('success');
        echo "Status: " . $this->paymentProcessor->getStatus() . "<br>";
    }
}

// Create an instance of PaymentTest
$paymentTest = new PaymentTest();

// Call the testInsertPaymentSuccess method to display the information in the browser
$paymentTest->testInsertPaymentSuccess();
?>